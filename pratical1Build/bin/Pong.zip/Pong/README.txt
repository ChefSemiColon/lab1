player 1 controls - 
 "A" to move paddle up
 "Z" to move paddle down

player 2 controls - 
 Up Arrow to move paddle up
 Down Arrrow to move paddle down